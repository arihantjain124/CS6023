Before running "evaluate.sh", make sure of the following things:
  1. Place your solution code "<ROLL_NO>.cu" in the "submit" directory
  2. Input files must follow the naming format: "input##.txt"
  3. Output files must follow the naming format: "output##.txt"
  4. Place the input files in the "testcases/input" directory
  5. Place the output files in the "testcases/output" directory
  6. Output in A2-Marks.txt: rollNumber, NumberOfTestCasesPassed