 1. use the main.cu file present in code folder.
 2. Rename the main.cu to your rollnumber.cu
 2. Don't change graph.hpp
 3. Create a folder in SUBMIT folder with name as your roll number
 5. copy only rollnumber.cu to SUBMIT/rollNumber folder don't copy graph.hpp
 6. check your score using evaluate.sh
 7. before running the evaluate.sh make sure that only rollnumber.cu is present in SUBMIT/rollNumber folder
